package com.edmilson.olamundo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = (Button) findViewById(R.id.mudarTexto);

        b1.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                TextView tv = (TextView)findViewById(R.id.texto);
                tv.setText("Olá Mundo!");
            }
        });

        Button b2 = (Button) findViewById(R.id.sumirTexto);
        b2.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                TextView tv = (TextView)findViewById(R.id.texto);
                if(tv.getVisibility()==View.VISIBLE){
                    tv.setVisibility(View.INVISIBLE);
                }
                else{
                    tv.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}